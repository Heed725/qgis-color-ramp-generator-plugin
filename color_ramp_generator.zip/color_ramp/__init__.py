def classFactory(iface):
    from .plugin import qGISColor_ramp_generator
    return qGISColor_ramp_generator(iface)
