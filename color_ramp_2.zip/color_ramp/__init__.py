def classFactory(iface):
    """Load the plugin class.
    
    Args:
        iface: A QGIS interface instance.
    Returns:
        Plugin class instance
    """
    from .plugin import qGISColor_ramp_generator
    return qGISColor_ramp_generator(iface)

# Define the path to the plugin's icon
def icon_path():
    """Get the path to the plugin's icon."""
    from os.path import dirname, join
    return join(dirname(__file__), 'icon.png')
